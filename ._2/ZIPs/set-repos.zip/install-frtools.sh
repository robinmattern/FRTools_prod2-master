#!/bin/bash

#  aRepo="FRTools_prod2-master"
#  aRepo="FRTools_/prod2-master"
#  aRepo="FRTools"

   aRepo="$1"; if [ "$1" == "" ]; then aRepo="FRTools"; fi
#  ----------------------------------------------------------------------------

   git clone https://github.com/robinmattern/FRTools_prod2-master.git "${aRepo}"
   cd ${aRepo}
   chmod 755 *.sh
   ./set-frtools.sh doit

   if [ "${OSTYPE:0:6}" == "darwin" ]; then rc_file=".zshrc" ; fi
   if [ "${OSTYPE:0:6}" != "darwin" ]; then rc_file=".bashrc"; fi

   echo -e "\n** You will need to run: source ~/${rc_file}\n"
