<!-- <script>document.redirect "http://92.112.184.206/set-repos.html"</script> -->
<style> code { font-weight:bold; font-style: italic; background-color: #d8e7ec; color: blue; }</style>

## Welcome to the formR Repos starter page
 
From your new Repos folder, you can either: (Option 3 is the easiest.)

   - Option 1 in a browser  

      - Download this file, <a href="https://raw.githubusercontent.com/robinmattern/FRTools_prod2-master/master/._2/ZIPs/set-repos">set-repos</a> (use: save link as...) 
      - Save it as <code>set-repos</code> in a Repos folder (with no extension)  
      - Run it with: <code>bash set-repos</code>  

   - Option 2 in a bash terminal  

      - Copy this line of code: <code>curl -s http&#58;//aidocs4u.com/set-repos | bash</code>
      - Paste it into the terminal 
      - Run it with ENTER        
       
   - Option 3 if the above link isn't available:

      - Copy this line of code:   
        <code>curl -s https&#58;//raw.githubusercontent.com/robinmattern/FRTools_prod2-master/master/._2/ZIPs/set-repos | bash</code>
      - Paste and run it in a terminal.  

 After that, you can run any of these install commands from your Repos folder: 
  
   - <code>bash install frtools # first, then </code>
   - <code>source ~/.zshrc, &nbsp;&nbsp;&nbsp; # then run, frt, to check it.</code>   
   - <code>bash install anyllm &nbsp;# then run, anyllm, to check it.</code>
   - <code>bash install aidocs &nbsp;# then run, aidocs, to check it.</code>
<!-- - <code>bash install aicoder # then run, aicoder, to check it</code> -->
