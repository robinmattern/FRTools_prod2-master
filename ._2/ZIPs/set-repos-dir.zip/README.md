<!-- <script>document.redirect "http://92.112.184.206/set-repos.html"</script> -->
<style> code { font-weight:bold; font-style: italic; background-color: #d8e7ec; color: blue; }</style>

## Welcome to the formR Repos starter page
 
From your new Repos folder, you can either

  - Option 1 in a browser  

      1. Download this file, <a href="http://92.112.184.206/set-repos">set-repos</a>  
      2. Save it as <code>set-repos</code> in a Repos folder   
      3. Run it with: <code>bash set-repos</code>      

  - Option 2 in a bash terminal  

      - Run it with: <code>curl -s http&#58;//92.112.184.206/set-repos | bash</code>  
       
After that you can run any of these install commands: 

  - <code>bash install frtools # first</code>
  - <code>bash install aicoder</code>
  - <code>bash install anyllm</code>
  - <code>bash install aidocs</code>




