#!/bin/bash

  ./re-install $1 install                                    # .(50105.04.1 RAM Add install)

  