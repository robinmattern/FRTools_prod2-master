#!/bin/bash

# ./re-install $1 install                                    ##.(50105.04.1 RAM Add install)
  bash re-install install $1 $2                              # .(50105.04.1 RAM Add install)

